#ifndef _INIT_
#define _INIT_

#include <iostream>
#include <random>
#include <algorithm>
#include <vector>
using std::vector;
#include <rarray>

rarray<int,2> init(int , int , rarray<int,2> );

#endif
