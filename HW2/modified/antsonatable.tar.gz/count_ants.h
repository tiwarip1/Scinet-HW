#ifndef _COUNT_ANTS_
#define _COUNT_ANTS_

#include <iostream>
#include <random>
#include <algorithm>
#include <vector>
using std::vector;

vector<int> count_ants(int, int, int*,bool);

#endif