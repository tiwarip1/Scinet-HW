#ifndef _INIT_
#define _INIT_

#include <iostream>
#include <random>
#include <algorithm>
#include <vector>
using std::vector;

int *init(int , int , int* );

#endif