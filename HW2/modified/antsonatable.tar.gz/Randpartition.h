#ifndef _RAND_PARTITION_
#define _RAND_PARTITION_

#include <iostream>
#include <random>
#include <algorithm>

void rand_partition(int, int, int*, size_t);

#endif